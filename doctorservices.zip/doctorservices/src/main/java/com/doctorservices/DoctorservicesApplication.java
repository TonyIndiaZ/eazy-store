package com.doctorservices;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.client.RestTemplate;



@EnableDiscoveryClient
@SpringBootApplication
@EnableScheduling  //For Enabling Scheduled Jobs
@EnableTransactionManagement
public class DoctorservicesApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(DoctorservicesApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		System.out.println("Doctor service running....");
		
	}
	
	@Bean
	public RestTemplate getRestTemplate() {
		return new RestTemplate();
	}
	

}
