package com.doctorservices.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.doctorservices.dto.FlightBookingAcknowledgement;
import com.doctorservices.dto.FlightBookingRequest;
import com.doctorservices.service.FlightBookingService;

@RestController
@RequestMapping("/v1/api/flightservice")
public class BookFlightController {
	
	@Autowired
	public FlightBookingService flightservice;
	
	
	@PostMapping("/bookFlightTicket")
	public FlightBookingAcknowledgement bookTicket(@RequestBody FlightBookingRequest request) {
		return flightservice.bookFlightTicket(request);
	}

}
