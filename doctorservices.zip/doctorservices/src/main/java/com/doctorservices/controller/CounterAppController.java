package com.doctorservices.controller;

import java.time.LocalDate;
import java.time.Month;
import java.time.Year;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.doctorservices.entity.CounterApp;
import com.doctorservices.request.CounterRequest;
import com.doctorservices.service.CounterAppService;


@RestController
@RequestMapping("/api/v1/counterapp")
public class CounterAppController {
	
	@Autowired
	private CounterAppService cas;
	
	//stncode : E 
	//sqtype : P
	private static final	Logger logger = LoggerFactory.getLogger(CounterAppController.class);
	private static final	String  Sq_Type = "P";
  
	@PostMapping("/add")
	public String saveCounter(@RequestBody CounterRequest counterRequest) {
		
		logger.info("CounterappController : saveCounter :: /add POST end point called {}",counterRequest);
		 String eventId ="";
		if("P".equalsIgnoreCase(counterRequest.getOpType())) {
		logger.info("CounterappController : P opeartion  :: create P operation start {}",counterRequest.getOpType());
		 Long sqnNbr= cas.createPEvent(counterRequest);
		 
         eventId = cas.getValidEventId(counterRequest.getOriginLocId(),Sq_Type ,sqnNbr);		
		logger.info(" eventId :: {} ", eventId);
		
		}else {
			Long sqnNbr= cas.createPEvent(counterRequest);
			eventId = cas.getValidEventId(counterRequest.getOriginLocId(),Sq_Type ,sqnNbr);		
				logger.info(" eventId :: {} ", eventId);
		}
		
		return eventId;
	}
	




}
