package com.doctorservices.controller;



import java.net.URI;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.doctorservices.entity.Doctor;
import com.doctorservices.exception.DoctorNotFoundException;
import com.doctorservices.exception.InvalidInputException;
import com.doctorservices.repository.DoctorRepository;
import com.doctorservices.service.DoctorServiceImpl;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;




@RestController
@RequestMapping("/api/v1/doctor")
//@CrossOrigin("*")
public class DoctorController {

	@Autowired
	private DoctorServiceImpl doctorServiceImp;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private DoctorRepository drepo;

	// save
	@Operation(summary = "Save Doctor Details",description = " This end point will save all info related to Doctor table")
	@ApiResponses({
		@ApiResponse(description = "Success", responseCode = "200"),
		@ApiResponse(description = "Bad Request", responseCode = "400"),
		@ApiResponse(description = "Internal Server Error", responseCode = "500")
	})
	@PostMapping("/save")
	public ResponseEntity<Doctor> saveDoctor( @RequestBody  Doctor d) {
		
		Doctor doctor1 = new Doctor();
		doctor1.setName(d.getName());
		
		Doctor savedoctor = doctorServiceImp.saveDoctor(doctor1);
		return new ResponseEntity<>(savedoctor, HttpStatus.CREATED);
	}

	// read - by Id
	
	@GetMapping("/{id}")
	public ResponseEntity<Optional<Doctor>> getDoctorById(@PathVariable Long id) {
		Optional<Doctor> doctor1 = doctorServiceImp.getDoctorById(id);
		return ResponseEntity.ok(doctor1);
	}

	@Operation(summary = "get allDoctor records",description = " This end point will get all info related to Doctors")
	@ApiResponses({
		@ApiResponse(description = "Success", responseCode = "200"),
		@ApiResponse(description = "Bad Request", responseCode = "400"),
		@ApiResponse(description = "Internal Server Error", responseCode = "500")
	})
	// read - by getAllDoctors
	@GetMapping("/alldoctors")
	public ResponseEntity<List<Doctor>> getAllDoctors() {
		List<Doctor> allDoctors = doctorServiceImp.getAllDoctors();
		return ResponseEntity.ok(allDoctors);

	}

	// delete - by id
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteDoctorById(@PathVariable Long id) {
		boolean flag = doctorServiceImp.deleteDoctorById(id);
		if (flag) {
			return ResponseEntity.ok("Doctor Deleted successfully");
		} else {
			throw new InvalidInputException(" Invalid Doctor Id!" );
		}

	}

    //update - by id 
	@PutMapping("/{id}")
	public ResponseEntity<Doctor> updateDoctorById(@PathVariable Long id, @RequestBody @Valid Doctor doctor) {
		Doctor updatedoctor = doctorServiceImp.updateDoctorById(id, doctor);
		return new ResponseEntity<>(updatedoctor, HttpStatus.OK);
	}
	
	
	
	
	//test -Rest Template
	@GetMapping("/test")
	public List<String> testString() {
		List<String> scheduleAvailable = Arrays.asList("Dentist- 10:00AM, Neurologist - 12:00PM");
		return scheduleAvailable;
	}

	

	
// JUNIT -Test
	
//	@GetMapping("/cust_Query/{name}")
//	public List<Doctor> getDoctorByName(@PathVariable String name){		   
//		return drepo.findByName(name);		
//	}

	
	public void getStringUtils() {		
		String str=null;
		
		if(StringUtils.isEmpty(str)){
			
		}
	}
	

}
