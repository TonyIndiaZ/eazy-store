package com.doctorservices.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.doctorservices.entity.Employee;
import com.doctorservices.service.EmployeeServiceImpl;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
@RequestMapping("/emp/v1/api")
public class EmployeeController {

	@Autowired
	private EmployeeServiceImpl empImpl;
	
	@PostMapping("/save")
	public Employee saveEmployee(@RequestBody Employee emp) {		
		Employee empployee = empImpl.saveEmployee(emp);	
		return empployee;
	}
	
	@GetMapping("/getallemployees")
	public List<Employee> getAllEmployees(){
		return empImpl.getAllEmployees();
	}
}
