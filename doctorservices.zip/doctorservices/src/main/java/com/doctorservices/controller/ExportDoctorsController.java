package com.doctorservices.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.doctorservices.service.ExportDoctorService;
import com.itextpdf.io.IOException;

import java.io.ByteArrayInputStream;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
 
import java.io.ByteArrayInputStream;


@RestController
@RequestMapping("/api/v1/export")
public class ExportDoctorsController {
	
	@Autowired
	private ExportDoctorService docservice;
	
	

	//xlsx
    @GetMapping("/xlsx")
    public ResponseEntity<byte[]> downloadExcel() {
	
    	 ByteArrayInputStream in = docservice.exportDoctorsToExcel();
    	 
    	 HttpHeaders headers = new HttpHeaders();
    	   headers.add("Content-Disposition", "attachment; filename=doc.xlsx");
    	
    	   
    	   return ResponseEntity
                   .ok()
                   .headers(headers)
                   .contentType(MediaType.APPLICATION_OCTET_STREAM)
                   .body(in.readAllBytes());
    }
    
    
    //pdf
    @GetMapping("/pdf")
    public ResponseEntity<byte[]> downloadPdf() throws IOException, java.io.IOException {
        ByteArrayInputStream in = docservice.exportDoctorsToPdf();
 
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "attachment; filename=docs.pdf");
 
        return ResponseEntity
                .ok()
                .headers(headers)
                .contentType(MediaType.APPLICATION_PDF)
                .body(in.readAllBytes());
    }
}



 

 
  
 


