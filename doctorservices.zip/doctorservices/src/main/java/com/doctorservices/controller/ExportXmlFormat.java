package com.doctorservices.controller;

import java.util.ArrayList;
import java.util.List;

import javax.xml.namespace.QName;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.doctorservices.entity.Doctor;
import com.doctorservices.service.DoctorServiceImpl;



@RestController
@RequestMapping(path="/api/v1/xml")
public class ExportXmlFormat {
	
	private final Logger logger = LoggerFactory.getLogger(ExportXmlFormat.class);
	
	@Autowired
	private DoctorServiceImpl dServiceImpl;
	
	
	@GetMapping(value="/doctor",produces = "application/xml")
	public Doctor exportXmlDoctor() {
		logger.info("ExportXmlFormatClass :: exportXmlDoctor :: /api/v1/xml/doctor  called :: start");
		Doctor doctor = new Doctor();
		doctor.setId(1L);
		doctor.setName("Tony");
		doctor.setMobile("9878987898");
		doctor.setSpecialisation("dentist");
		doctor.setExperience(3);
		logger.info("ExportXmlFormatClass :: exportXmlDoctor :: /api/v1/xml/doctor called :: End :: "+doctor);
		return doctor;
	}
	
	
	@GetMapping(value="/doctorsList",produces = "application/xml")
	public 	List<Doctor> exportXmlDoctorsList() {
		logger.info("ExportXmlFormatClass :: exportXmlDoctorsList :: /api/v1/xml/doctorsList called :: start");
		//find all doctors
		List<Doctor> extractdocs= new ArrayList<>();	
	for(Doctor doctor: dServiceImpl.getAllDoctors()) {
		extractdocs.add(doctor);
	}
		logger.info("ExportXmlFormatClass :: exportXmlDoctorsList :: /api/v1/xml/doctorsList called :: End :: "+extractdocs);
	        return extractdocs;
	}

	
	// read - data from XML
	
	
}
