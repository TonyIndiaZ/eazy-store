package com.doctorservices.controller;


import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ctc.wstx.util.StringUtil;
import com.doctorservices.entity.Doctor;

import com.doctorservices.service.PaginationService;


import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@Tag(name="Pagination Controller")
@RequestMapping("/api/v1/page")
public class PaginationController {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private PaginationService pservice;
	
	@GetMapping("/doctors")
	public List<Doctor> pageWiseDoctors( @RequestParam(defaultValue = "0") int page ,
		 @RequestParam(defaultValue = "3") int size ) {			
		logger.info("PaginationController :: pageWiseDoctors :: /GET api called : START ");
		return pservice.getDoctors(page, size);
	}
}
