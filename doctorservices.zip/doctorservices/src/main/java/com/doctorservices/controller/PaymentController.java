package com.doctorservices.controller;

public class PaymentController {

}
