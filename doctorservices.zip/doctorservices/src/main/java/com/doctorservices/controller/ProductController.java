package com.doctorservices.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.doctorservices.entity.Product;
import com.doctorservices.service.ProductService;

@RestController
@RequestMapping("/v1/api/product")
public class ProductController {
	
	@Autowired
	private ProductService productService;
	

	 @GetMapping("/{id}")
	    public Product getProduct(@PathVariable Long id) {
	        return productService.getProduct(id);
	    }

	    @PostMapping
	    public Product createProduct(@RequestBody Product product) {
	        return productService.createProduct(product);
	    }

	    @PutMapping
	    public Product updateProduct(@RequestBody Product product) {
	        return productService.updateProduct(product);
	    }

	    @DeleteMapping("/{id}")
	    public void deleteProduct(@PathVariable Long id) {
	        productService.deleteProduct(id);
	    }
}
