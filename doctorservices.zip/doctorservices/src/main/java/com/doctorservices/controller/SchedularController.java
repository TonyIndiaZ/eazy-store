package com.doctorservices.controller;

public class SchedularController {

}
