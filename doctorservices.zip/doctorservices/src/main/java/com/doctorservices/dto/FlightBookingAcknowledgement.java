package com.doctorservices.dto;

import com.doctorservices.entity.PassengerInfo;

public class FlightBookingAcknowledgement {
	
	private String status;
	private Double totalFare;
	private String pnrNo;
	private PassengerInfo passengerInfo;
	
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Double getTotalFare() {
		return totalFare;
	}
	public void setTotalFare(Double totalFare) {
		this.totalFare = totalFare;
	}
	public String getPnrNo() {
		return pnrNo;
	}
	public void setPnrNo(String pnrNo) {
		this.pnrNo = pnrNo;
	}
	public PassengerInfo getPassengerInfo() {
		return passengerInfo;
	}
	public void setPassengerInfo(PassengerInfo passengerInfo) {
		this.passengerInfo = passengerInfo;
	}
	public FlightBookingAcknowledgement() {
		super();
		// TODO Auto-generated constructor stub
	}
	public FlightBookingAcknowledgement(String status, Double totalFare, String pnrNo, PassengerInfo passengerInfo) {
		super();
		this.status = status;
		this.totalFare = totalFare;
		this.pnrNo = pnrNo;
		this.passengerInfo = passengerInfo;
	}
	@Override
	public String toString() {
		return "FlightBookingAcknowledgement [status=" + status + ", totalFare=" + totalFare + ", pnrNo=" + pnrNo
				+ ", passengerInfo=" + passengerInfo + "]";
	}
	
	
	
 
}
