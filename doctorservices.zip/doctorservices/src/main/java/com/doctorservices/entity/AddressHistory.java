package com.doctorservices.entity;

import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;


@Embeddable
public class AddressHistory {

	@Column(name = "CITY")
	private String city;
	@Column(name = "STATE")
	private String state;
	@Column(name = "MODIFIED_BY")
	private String modifiedBy;
	@Column(name = "MODIFIED_ON")
	private Date modifiedOn;
	
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	
	public AddressHistory() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AddressHistory(String modifiedBy, Date modifiedOn) {
		super();
		this.modifiedBy = modifiedBy;
		this.modifiedOn = modifiedOn;
	}
	
	public AddressHistory(String city, String state, String modifiedBy, Date modifiedOn) {
		super();
		this.city = city;
		this.state = state;
		this.modifiedBy = modifiedBy;
		this.modifiedOn = modifiedOn;
	}
	@Override
	public String toString() {
		return "AddressHistory [city=" + city + ", state=" + state + ", modifiedBy=" + modifiedBy + ", modifiedOn="
				+ modifiedOn + "]";
	}
	
	
	
}
