package com.doctorservices.entity;

import java.util.Date;



import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "COUNTER_APP")
public class CounterApp {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;	
	private String sqType;	// PP :: LL
	private String stnCode; //EVENT
	private Long sqNbr;
	private Date createdDt;
	private Date modifiedDt;
	private String lastyymm;
	
	
	
	public CounterApp() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getLastyymm() {
		return lastyymm;
	}
	public void setLastyymm(String lastyymm) {
		this.lastyymm = lastyymm;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getSqType() {
		return sqType;
	}
	public void setSqType(String sqType) {
		this.sqType = sqType;
	}
	public String getStnCode() {
		return stnCode;
	}
	public void setStnCode(String stnCode) {
		this.stnCode = stnCode;
	}
	public Long getSqNbr() {
		return sqNbr;
	}
	public void setSqNbr(Long sqNbr) {
		this.sqNbr = sqNbr;
	}
	public Date getCreatedDt() {
		return createdDt;
	}
	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}
	public Date getModifiedDt() {
		return modifiedDt;
	}
	public void setModifiedDt(Date modifiedDt) {
		this.modifiedDt = modifiedDt;
	}
	public CounterApp(Long id, String sqType, String stnCode, Long sqNbr, Date createdDt, Date modifiedDt,
			String lastyymm) {
		super();
		this.id = id;
		this.sqType = sqType;
		this.stnCode = stnCode;
		this.sqNbr = sqNbr;
		this.createdDt = createdDt;
		this.modifiedDt = modifiedDt;
		this.lastyymm = lastyymm;
	}
	@Override
	public String toString() {
		return "CounterApp [id=" + id + ", sqType=" + sqType + ", stnCode=" + stnCode + ", sqNbr=" + sqNbr
				+ ", createdDt=" + createdDt + ", modifiedDt=" + modifiedDt + ", lastyymm=" + lastyymm + "]";
	}

	
	
	

}
