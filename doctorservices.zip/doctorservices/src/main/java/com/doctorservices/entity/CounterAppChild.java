package com.doctorservices.entity;

import java.io.Serializable;
import java.util.Date;



import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "COUNTER_APP_C")
public class CounterAppChild  implements Serializable{
	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;	
	private String sqType;	 // PP :: LL
	private String stnCode;  // EVENT 
	private Long missedSqNbr;
	private Date createdDt;
	private Date modifiedDt;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getSqType() {
		return sqType;
	}
	public void setSqType(String sqType) {
		this.sqType = sqType;
	}
	public String getStnCode() {
		return stnCode;
	}
	public void setStnCode(String stnCode) {
		this.stnCode = stnCode;
	}
	public Long getMissedSqNbr() {
		return missedSqNbr;
	}
	public void setMissedSqNbr(Long missedSqNbr) {
		this.missedSqNbr = missedSqNbr;
	}
	public Date getCreatedDt() {
		return createdDt;
	}
	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}
	public Date getModifiedDt() {
		return modifiedDt;
	}
	public void setModifiedDt(Date modifiedDt) {
		this.modifiedDt = modifiedDt;
	}
	public CounterAppChild() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CounterAppChild(Long id, String sqType, String stnCode, Long missedSqNbr, Date createdDt, Date modifiedDt) {
		super();
		this.id = id;
		this.sqType = sqType;
		this.stnCode = stnCode;
		this.missedSqNbr = missedSqNbr;
		this.createdDt = createdDt;
		this.modifiedDt = modifiedDt;
	}
	@Override
	public String toString() {
		return "CounterAppChild [id=" + id + ", sqType=" + sqType + ", stnCode=" + stnCode + ", missedSqNbr="
				+ missedSqNbr + ", createdDt=" + createdDt + ", modifiedDt=" + modifiedDt + "]";
	}

	
}
