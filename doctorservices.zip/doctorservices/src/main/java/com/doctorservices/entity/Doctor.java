package com.doctorservices.entity;



import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import jakarta.persistence.Table;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;


//@Getter
//@Setter
//@NoArgsConstructor
//@AllArgsConstructor
@Table(name = "doctor")
@Entity
//@JacksonXmlRootElement(localName = "Doctor")
public class Doctor {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    @JacksonXmlProperty(localName = "id")
	private Long id;

	//@Column(nullable = false)
	//@NotBlank(message = "Name cannot be blank")
    //@JacksonXmlProperty(localName = "name")
	private String name;

	//@Column(nullable = false)
	//@Min(value = 18, message = "Age must greater than 18 years")
	  //@JacksonXmlProperty(localName = "age")
	private Integer age;

	//@Column(nullable = false)
	//@Size(min = 10, max = 10, message = "mobile must conatins 10 digits")
	 // @JacksonXmlProperty(localName = "mobile")
	private String mobile;

	//@Column(nullable = false)
	//@NotBlank(message = "specialisation cannot be blank")
	 // @JacksonXmlProperty(localName = "specialisation")
	private String specialisation;

	//@Column(nullable = false)
	 // @JacksonXmlProperty(localName = "experience")
	private Integer experience;
	

	

	
	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getSpecialisation() {
		return specialisation;
	}

	public void setSpecialisation(String specialisation) {
		this.specialisation = specialisation;
	}

	public Integer getExperience() {
		return experience;
	}

	public void setExperience(Integer experience) {
		this.experience = experience;
	}

	public Doctor(Long id, String name, Integer age, String mobile, String specialisation, Integer experience) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.mobile = mobile;
		this.specialisation = specialisation;
		this.experience = experience;
	}

	public Doctor() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Doctor [id=" + id + ", name=" + name + ", age=" + age + ", mobile=" + mobile + ", specialisation="
				+ specialisation + ", experience=" + experience + "]";
	}

}
