package com.doctorservices.entity;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.Table;

@Entity
@Table(name = "EMPLOYEES_DATA")
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "EMPLOYEE_ID")
	private Long empId;
	@Column(name = "EMPLOYEE_NAME")
	private String empName;
	
	@ElementCollection(fetch = FetchType.EAGER)
	@JoinTable(name = "ADDRESS_HISTORY_DATA", joinColumns = @JoinColumn(name = "EMPLOYEE_ID") )
	private List<AddressHistory> addressHistory = new ArrayList<>();

	
	
	public Long getEmpId() {
		return empId;
	}

	public void setEmpId(Long empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public List<AddressHistory> getAddressHistory() {
		return addressHistory;
	}

	public void setAddressHistory(List<AddressHistory> addressHistory) {
		this.addressHistory = addressHistory;
	}

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(Long empId, String empName, List<AddressHistory> addressHistory) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.addressHistory = addressHistory;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", addressHistory=" + addressHistory + "]";
	}
	
	
	

}
