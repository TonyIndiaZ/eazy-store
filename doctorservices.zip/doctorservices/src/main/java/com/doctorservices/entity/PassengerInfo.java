package com.doctorservices.entity;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "PASSENGER_INFO")
public class PassengerInfo {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long pId;
	private String name;
	private String source;
	private String destination;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
	private Date  travelDate;
	private double fare;
	
	
	public double getFare() {
		return fare;
	}
	public void setFare(double fare) {
		this.fare = fare;
	}
	public Long getpId() {
		return pId;
	}
	public void setpId(Long pId) {
		this.pId = pId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public Date getTravelDate() {
		return travelDate;
	}
	public void setTravelDate(Date travelDate) {
		this.travelDate = travelDate;
	}
	public PassengerInfo(Long pId, String name, String source, String destination, Date travelDate, Double fare) {
		super();
		this.pId = pId;
		this.name = name;
		this.source = source;
		this.destination = destination;
		this.travelDate = travelDate;
		this.fare = fare;
	}
	public PassengerInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PassengerInfo(Long pId, String name, String source, String destination, Date travelDate, double fare) {
		super();
		this.pId = pId;
		this.name = name;
		this.source = source;
		this.destination = destination;
		this.travelDate = travelDate;
		this.fare = fare;
	}
	

	
	
}
