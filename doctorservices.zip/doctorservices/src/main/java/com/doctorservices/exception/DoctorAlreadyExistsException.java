package com.doctorservices.exception;

@SuppressWarnings("serial")
public class DoctorAlreadyExistsException extends RuntimeException{
	public DoctorAlreadyExistsException(String message) {
		super(message);
	}
}
