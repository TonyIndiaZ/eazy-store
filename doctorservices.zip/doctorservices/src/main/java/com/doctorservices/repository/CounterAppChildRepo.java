package com.doctorservices.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.doctorservices.entity.CounterAppChild;


@Repository
public interface CounterAppChildRepo extends JpaRepository<CounterAppChild, Long>{
	
//	@Lock(LockModeType.PESSIMISTIC_READ)
	@Query(name =  "select * from counter_app_c  where stnCode=:stnCode and sqType=:sqType",nativeQuery = true)
	CounterAppChild findByStnCodeAndSqType(@Param("stnCode")String stnCode, @Param("sqType")String sqType);  // eve : E op: P

	@Query(name =  "delete from counter_app_c  where missedSqNbr=:sqNbrRes",nativeQuery = true)
	void deleteByMissedSqNbr(@Param("missedSqNbr")Long sqNbrRes);
	

}
