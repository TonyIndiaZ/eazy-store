package com.doctorservices.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.doctorservices.entity.CounterApp;

@Repository
public interface CounterAppRepo extends JpaRepository<CounterApp, Long>{

	@Query(name =  "select * from counter_app  where stnCode=:stnCode and sqType=:sqType",nativeQuery = true)
	CounterApp findOneByStnCodeAndSqType(@Param("stnCode")String stnCode, @Param("sqType")String sqType);

}
