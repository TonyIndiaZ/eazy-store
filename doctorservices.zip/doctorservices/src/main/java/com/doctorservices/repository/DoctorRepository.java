package com.doctorservices.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.doctorservices.entity.Doctor;



@Repository
public interface DoctorRepository extends JpaRepository<Doctor, Long> {
	
//    @Query(value="SELECT * FROM doctor WHERE name=:name",nativeQuery=true)
//	public List<Doctor> findByName(String name);
    
    public Doctor findByName(String name);
	

}