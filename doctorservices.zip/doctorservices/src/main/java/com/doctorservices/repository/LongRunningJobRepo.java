package com.doctorservices.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.doctorservices.entity.SchedularTask;

@Repository
public interface LongRunningJobRepo extends JpaRepository<SchedularTask, Integer>{

}
