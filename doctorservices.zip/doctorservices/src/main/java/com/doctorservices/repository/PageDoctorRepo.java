package com.doctorservices.repository;

import java.util.List;

import org.springdoc.core.converters.models.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.doctorservices.entity.Doctor;

@Repository
public interface PageDoctorRepo extends PagingAndSortingRepository<Doctor, Long>{

	@Query(value="SELECT * FROM doctor",nativeQuery=true)
	List<Doctor> findAll(Pageable pageable);
}
