package com.doctorservices.request;

import java.util.Date;

public class CounterRequest {
	
	private String eventId;
	private String opType; //P : L
	private Date createdDate;	
	private String originLocId;
	
	
	public String getEventId() {
		return eventId;
	}
	public void setEventId(String eventId) {
		this.eventId = eventId;
	}
	public String getOpType() {
		return opType;
	}
	public void setOpType(String opType) {
		this.opType = opType;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public String getOriginLocId() {
		return originLocId;
	}
	public void setOriginLocId(String originLocId) {
		this.originLocId = originLocId;
	}
	public CounterRequest() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CounterRequest(String eventId, String opType, Date createdDate, String originLocId) {
		super();
		this.eventId = eventId;
		this.opType = opType;
		this.createdDate = createdDate;
		this.originLocId = originLocId;
	}
	@Override
	public String toString() {
		return "CounterRequest [eventId=" + eventId + ", opType=" + opType + ", createdDate=" + createdDate
				+ ", originLocId=" + originLocId + "]";
	}

	
	
}
