package com.doctorservices.response;

import java.util.List;

import com.doctorservices.entity.Doctor;

public class PageResponse {
	
	private List<Doctor> doctors;
	private int currentPage;
	private int totalItems;
	private int totalPages;
	
	
	
	public PageResponse(List<Doctor> doctors, int currentPage, int totalItems, int totalPages) {
		super();
		this.doctors = doctors;
		this.currentPage = currentPage;
		this.totalItems = totalItems;
		this.totalPages = totalPages;
	}
	public List<Doctor> getDoctors() {
		return doctors;
	}
	public void setDoctors(List<Doctor> doctors) {
		this.doctors = doctors;
	}
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public int getTotalItems() {
		return totalItems;
	}
	public void setTotalItems(int totalItems) {
		this.totalItems = totalItems;
	}
	public int getTotalPages() {
		return totalPages;
	}
	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}
	public PageResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
