package com.doctorservices.service;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.Year;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.doctorservices.entity.CounterApp;
import com.doctorservices.entity.CounterAppChild;
import com.doctorservices.repository.CounterAppChildRepo;
import com.doctorservices.repository.CounterAppRepo;
import com.doctorservices.request.CounterRequest;

@Service
public class CounterAppService {

	@Autowired
	private CounterAppChildRepo childrepo;

	@Autowired
	private CounterAppRepo repo;

	private static final Logger logger = LoggerFactory.getLogger(CounterAppService.class);

	private static final String Event_Type = "E";
	private static final String P = "P";
	private static final String L = "L";

	public Long createPEvent(CounterRequest cr) {

		Long sqNbr = getSqnNbrFromCounterAppChild(Event_Type, cr.getOpType());
		sqNbr = next(Event_Type, cr.getOpType(), sqNbr);
		return sqNbr;
	}

	private Long getSqnNbrFromCounterAppChild(String eventType, String opType) {
		String stnCode = eventType;
		Long sqNbrRes = null;
		CounterAppChild c = childrepo.findByStnCodeAndSqType(stnCode, opType);

		if (c != null) {
			sqNbrRes = c.getMissedSqNbr();
			Long id = c.getId();
			if (sqNbrRes != null && id != null) {
				childrepo.deleteById(id);
				logger.info("next :: {}", sqNbrRes);
			}

		}

		return sqNbrRes;
	}

	private Long next(String eventType, String opType, Long sqNbr) {
		CounterApp ca = repo.findOneByStnCodeAndSqType(eventType, opType);
		logger.info("next :: {}", ca);

		Date createdDate = ca.getCreatedDt();

		SimpleDateFormat sdf = new SimpleDateFormat("yy");
		SimpleDateFormat sdf1 = new SimpleDateFormat("MM");

		String createdYear = sdf.format(createdDate);
		String createdMonth = sdf1.format(createdDate);

		String createdYearMonth = createdYear.concat(createdMonth);
		String currentYearMonth = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yy"))
				.concat(LocalDateTime.now().format(DateTimeFormatter.ofPattern("MM")));

		if (Optional.ofNullable(ca).isPresent()) {

			if (!ca.getLastyymm().equalsIgnoreCase(currentYearMonth)) {
				logger.info("restart sequenec :: createdYearMonth {}, currentYearMonth {}", createdYearMonth,
						currentYearMonth);
				ca.setSqNbr(1L);
				ca.setSqType(opType);
				ca.setStnCode(eventType);
				ca.setLastyymm(currentYearMonth);
				ca.setCreatedDt(new Date());
				ca.setModifiedDt(new Date());

			} else {
				if (sqNbr != null) {
					ca.setSqNbr(sqNbr + 1L);
					ca.setModifiedDt(new Date());
				} else {
					ca.setSqNbr(ca.getSqNbr() + 1L);
					ca.setModifiedDt(new Date());
				}

			}

		} else {
			ca.setSqNbr(1L);
			ca.setSqType(opType);
			ca.setStnCode(eventType);
			ca.setLastyymm(currentYearMonth);
			ca.setCreatedDt(new Date());
			ca.setModifiedDt(new Date());

		}

		ca = repo.save(ca);
		logger.info("next :: {}", ca);
		return ca.getSqNbr();
	}

	public String getValidEventId(String originLocId, String sqType, Long sqnNbr) {

		String currentYear = Year.now().format(DateTimeFormatter.ofPattern("uu"));
		Month month = Month.from(LocalDate.now());
		int sys = month.getValue();

		String sqnNbrId = org.apache.commons.lang.StringUtils.leftPad(String.valueOf(sqnNbr), 5, "0");
		String currentMonth = org.apache.commons.lang.StringUtils.leftPad(String.valueOf(sys), 2, "0");

		logger.info("getValidEventId :: originLocId {},sqType {} ,sqnNbrID {}, currentYear {}, currentMonth {} ",
				originLocId, sqType, sqnNbrId, currentYear, currentMonth);
		String eventId = "";
		if ("P".equalsIgnoreCase(sqType)) {

			eventId = originLocId + P + currentYear + currentMonth + sqnNbrId;

		} else {
			eventId = originLocId + L + currentYear + currentMonth + sqnNbrId;
		}
		logger.info("eventId :: {}", eventId);
		return eventId;
	}

}
