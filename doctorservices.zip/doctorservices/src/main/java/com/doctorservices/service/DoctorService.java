package com.doctorservices.service;


import java.util.List;
import java.util.Optional;

import com.doctorservices.entity.Doctor;



public interface DoctorService {

	// save
	public Doctor saveDoctor(Doctor doctor);

	// read -by Id 
	public Optional<Doctor> getDoctorById(long id);
	
	// read - getAllDoctors
	public List<Doctor> getAllDoctors();

	// delete - by Id
	public Boolean deleteDoctorById(long id);
	
	
	//update - by Id
	public Doctor updateDoctorById(long id,Doctor doctor );

	public Doctor getDoctorByName(String name) throws Exception;

	
}
