package com.doctorservices.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.doctorservices.entity.Doctor;
import com.doctorservices.exception.DoctorNotFoundException;
import com.doctorservices.repository.DoctorRepository;

@Service
public class DoctorServiceImpl implements DoctorService {

	@Autowired
	private DoctorRepository doctorRepository;

	// save - doctor
	@Override
	public Doctor saveDoctor(Doctor doctor) {
		return doctorRepository.save(doctor);
	}

	// read - by id
	@Override
	public Optional<Doctor> getDoctorById(long id) {

		return Optional.of(doctorRepository.findById(id)
				.orElseThrow(() -> new DoctorNotFoundException("Doctor Not Found with Id : " + id)));
	}

	// read - getAllDoctors
	@Override
	public List<Doctor> getAllDoctors() {
		return doctorRepository.findAll();
	}

	// delete - by id
	@Override
	public Boolean deleteDoctorById(long id) {

		Optional<Doctor> doctor = doctorRepository.findById(id);
		if (doctor.isPresent()) {
			doctorRepository.deleteById(id);
			return true;
		}
		return false;

	}

	@Override
	public Doctor updateDoctorById(long id, Doctor doctor) {
		try {
			Doctor editDoctor = doctorRepository.findById(id).get();
			editDoctor.setName(doctor.getName());
			editDoctor.setAge(doctor.getAge());
			editDoctor.setMobile(doctor.getMobile());
			editDoctor.setSpecialisation(doctor.getSpecialisation());
			editDoctor.setExperience(doctor.getExperience());
			return doctorRepository.save(editDoctor);
		} catch (Exception ex) {
			throw new DoctorNotFoundException("Doctor Not Found with Id : " + id);
		}
	}

	@Override
	public Doctor getDoctorByName(String name) throws Exception{

		Optional<Doctor> doctor = Optional.of(doctorRepository.findByName(name));
		if (!doctor.isPresent()) {
			throw new Exception("Doctor not found with name : " + name);
		}
        return doctor.get();
	}
	

}
