package com.doctorservices.service;

import java.util.List;

import com.doctorservices.entity.Employee;

public interface EmployeeService {

	public Employee saveEmployee(Employee Emp);
	
	public List<Employee> getAllEmployees();
}
