package com.doctorservices.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.doctorservices.entity.AddressHistory;
import com.doctorservices.entity.Employee;
import com.doctorservices.repository.EmployeeRepo;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepo empRepo;
	
	@Override
	public Employee saveEmployee(Employee Emp) {

		Employee emp = new Employee();
		emp.setEmpId(emp.getEmpId());
		emp.setEmpName(emp.getEmpName());

		List<AddressHistory> adList = new ArrayList<>();
		for (AddressHistory ad : emp.getAddressHistory()) {
			adList.add(new AddressHistory(emp.getEmpName(), ad.getModifiedOn()));
		}
		emp.setAddressHistory(adList);	
		empRepo.save(emp);
		return emp;
	}



	@Override
	public List<Employee> getAllEmployees() {	
		return empRepo.findAll();
	}

}
