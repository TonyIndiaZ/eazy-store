package com.doctorservices.service;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.doctorservices.entity.Doctor;
import com.doctorservices.repository.DoctorRepository;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.List;

import com.itextpdf.io.IOException;
import com.itextpdf.kernel.color.Color;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;

@Service
public class ExportDoctorService {

	private static final Logger logger = LoggerFactory.getLogger(ExportDoctorService.class);
	@Autowired
	private DoctorRepository drepo;
	
	
	
	public List<Doctor> getAllDoctors() {
		return drepo.findAll();
	}

	
	// xlsx - > Headers - >font ,style ,rows,cols and sizes
	public ByteArrayInputStream exportDoctorsToExcel() {
        logger.info(":: Export -XLSX  :: ExportDoctorService :: Class :: Serivice Class ::exportDoctorsToExcel :: Method :::  START :::");
		String[] cols = { "id", "name", "age" };
		List<Doctor> doctors = getAllDoctors();

		try {
			Workbook workbook = new XSSFWorkbook();
			ByteArrayOutputStream out = new ByteArrayOutputStream();

			Sheet sheet = workbook.createSheet("doctors");
			
			//Headers -styles
			
			Font hfont = workbook.createFont();
			hfont.setBold(true);
			hfont.setFontHeightInPoints((short)12);
			hfont.setColor(IndexedColors.WHITE.getIndex());
			
			
			//set -purple bg for Headers
			CellStyle hcellstyle = workbook.createCellStyle();
			hcellstyle.setFont(hfont);
			hcellstyle.setFillForegroundColor(IndexedColors.DARK_BLUE.getIndex());
			hcellstyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			hcellstyle.setAlignment(HorizontalAlignment.CENTER);
			applyBorders(hcellstyle);

			//light grey bg
			CellStyle lightGreyStyle = workbook.createCellStyle();
			lightGreyStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
			lightGreyStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			lightGreyStyle.setAlignment(HorizontalAlignment.CENTER);
			applyBorders(lightGreyStyle);
			
			//white cell - data bg
			CellStyle whiteGreyStyle = workbook.createCellStyle();
			whiteGreyStyle.setFillForegroundColor(IndexedColors.WHITE.getIndex());
			whiteGreyStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			whiteGreyStyle.setAlignment(HorizontalAlignment.CENTER);
			applyBorders(whiteGreyStyle);
		
			// Headers -row
			Row headerRow = sheet.createRow(0);
			 
			            for (int col = 0; col < cols.length; col++) {
			                Cell cell = headerRow.createCell(col);
			                cell.setCellValue(cols[col]);
			                cell.setCellStyle(hcellstyle);
			            }
			 
			            // Create data rows with alternating row colors
			            int rowIdx = 1;
			            for (Doctor doc : doctors) {
			                Row row = sheet.createRow(rowIdx);
			 
			                CellStyle rowStyle = (rowIdx % 2 == 0) ? lightGreyStyle : whiteGreyStyle;
			 
			                Cell cell0 = row.createCell(0);
			                cell0.setCellValue(doc.getId());
			                cell0.setCellStyle(rowStyle);
			 
			                Cell cell1 = row.createCell(1);
			                cell1.setCellValue(doc.getName());
			                cell1.setCellStyle(rowStyle);
			 
			                Cell cell2 = row.createCell(2);
			                cell2.setCellValue(doc.getAge());
			                cell2.setCellStyle(rowStyle);
			 
			                rowIdx++;
			            }
			
			
			workbook.write(out);
		   logger.info(":: Export -XLSX  :: ExportDoctorService :: Class :: Serivice Class ::exportDoctorsToExcel :: Method :::  END ::");
			return new ByteArrayInputStream(out.toByteArray());

		} catch (Exception e) {
			throw new RuntimeException("Failed to export data to Excel file", e);
		}
	}
	
	
	//apply Borders - xlsx
    private void applyBorders(CellStyle style) {
    	style.setBorderTop(BorderStyle.THIN);
    	style.setBorderBottom(BorderStyle.THIN);
    	style.setBorderLeft(BorderStyle.THIN);
    	style.setBorderRight(BorderStyle.THIN);
    }
	
	
	//PDF 
    public ByteArrayInputStream exportDoctorsToPdf() throws IOException, java.io.IOException {
    	
    	List<Doctor> doctors = getAllDoctors();
        try (
        ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            PdfWriter writer = new PdfWriter(out);
            PdfDocument pdfDoc = new PdfDocument(writer);
            Document document = new Document(pdfDoc);
 
            // Add title
            document.add(new Paragraph("List of Doctors").setFontSize(18).setBold());
 
            // Add a table with column headers
            float[] columnWidths = {1, 3, 3};
            Table table = new Table(columnWidths);
            table.addHeaderCell("ID");
            table.addHeaderCell("Name");
            table.addHeaderCell("Mobile");
 
            // Add rows
            for (Doctor doctor : doctors) {
                table.addCell(doctor.getId().toString());
                table.addCell(doctor.getName());
                table.addCell(doctor.getMobile());
            }
 
            document.add(table);
            document.close();
 
            return new ByteArrayInputStream(out.toByteArray());
 
        } catch (IOException e) {
            throw new RuntimeException("Failed to export data to PDF file", e);
        }
    }
		
    
    


}





 


 






