package com.doctorservices.service;

import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;

import com.doctorservices.dto.FlightBookingAcknowledgement;
import com.doctorservices.dto.FlightBookingRequest;
import com.doctorservices.entity.PassengerInfo;
import com.doctorservices.entity.PaymentInfo;
import com.doctorservices.repository.PassengerInfoRepo;
import com.doctorservices.repository.PaymentInfoRepo;
import com.doctorservices.utilHelper.PaymentUtils;

import jakarta.transaction.Transactional;

@Service
public class FlightBookingService {

	@Autowired
	private PassengerInfoRepo passengerInfoRepo;
	@Autowired
	private PaymentInfoRepo paymentInfoRepo;
	
	@Transactional
	public FlightBookingAcknowledgement bookFlightTicket(FlightBookingRequest request) {
				
		PassengerInfo passengerInfo = request.getPassengerInfo();
		passengerInfo = passengerInfoRepo.save(passengerInfo);
		
		PaymentInfo paymentInfo = request.getPaymentInfo();
		
		//TRUE orFALSE
		PaymentUtils.validateCreaditLimit(paymentInfo.getAccountNo(), passengerInfo.getFare());
		
		paymentInfo.setPassengerId(passengerInfo.getpId());
		paymentInfo.setAmount(passengerInfo.getFare());
		paymentInfoRepo.save(paymentInfo);
		
		return new FlightBookingAcknowledgement("SUCCESS", passengerInfo.getFare(), UUID.randomUUID().toString().split("-")[0], passengerInfo);
	}

	@Transactional
	public PassengerInfo  getPassengerInfo(Long id) {		
		PassengerInfo pInfo = null;
		pInfo = passengerInfoRepo.findById(id).get();
		if(Optional.ofNullable(pInfo).isPresent()) {
			return pInfo;
		}		
		return pInfo;
	}
	
	
}
