package com.doctorservices.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.doctorservices.entity.Doctor;
import com.doctorservices.repository.DoctorRepository;
import com.doctorservices.repository.PageDoctorRepo;

@Service
public class PaginationService {
	
	@Autowired
	private PageDoctorRepo pagedrepo;
	@Autowired
	private DoctorRepository drepo;


	public List<Doctor> getDoctors(int page,int size){
		PageRequest pageRequest= PageRequest.of(page, size);
		//Sort - name - ascending
		//PageRequest pageRequest= PageRequest.of(page, size,Sort.by("name").ascending());
		Page<Doctor> pageinDoctor = pagedrepo.findAll(pageRequest);	
		return pageinDoctor.getContent();
	}
	
	//All 
	public List<Doctor> getAllListOfDoctors(int page,int size){
		PageRequest pageable= PageRequest.of(page, size);
		List<Doctor>alldocs= drepo.findAll();
		int totalDbRecords =alldocs.size();
		int maxRecordsInPage = pageable.getPageSize();
		int pageNumber =pageable.getPageNumber();
		
		int from = page * maxRecordsInPage; 
		int to = from + maxRecordsInPage;
		
		if(to>maxRecordsInPage) {
			to=maxRecordsInPage;
		}
		
		PageRequest pageRequest= PageRequest.of(from, to);
		Page<Doctor> pageinDoctor = drepo.findAll(pageRequest);	
		return pageinDoctor.getContent();
	}
}
