package com.doctorservices.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.doctorservices.entity.SchedularTask;
import com.doctorservices.repository.LongRunningJobRepo;

@Service
public class SchedularService {

	private static final Logger logger = LoggerFactory.getLogger(SchedularService.class);

	@Autowired
	private LongRunningJobRepo longrunjob;

	// schdualr job to insert records into DB after every 5 seconds

	// @Scheduled(fixedRate = 5000) //add records every 5 seconds

	/**
	 * - 0 start from 0 sec
	 * -`*`/15: Every 10 minutes
	 *  - * - Every Hour 
	 *  - * - Every Day 
	 *  - * - Every Month
	 * - * - Every Year
	 */
	//@Scheduled(cron = "0 */2 * * * * ") //2 min
	//@Scheduled(cron = "${cron.expression.value}")  // Read expression from properties file
	public void add2DB() {
		SchedularTask st = new SchedularTask();
		st.setName("user" + new Random().nextInt(500000));
		SchedularTask newSt = longrunjob.save(st);
		logger.info("SchedularService :: add2DB :: add  service call in {} :: {}", new Date().toString(), newSt);
	}

	// schdualr job to fetch records from DB after every 15 seconds

	/*
	 * 0/15 - Every 15 sec 
	 * * - Every min 
	 * * - Every Hour 
	 * * - Every Day 
	 * * - Every Day of the Month
	 * * - Every Day of the Week
	 * 
	 */

	//@Scheduled(cron = "0 */3 * * * * ") // 3  min 
	public void fetchDB() {
		List<SchedularTask> list = longrunjob.findAll();
		logger.info("SchedularService :: Fetchall :: add  service call in {} ", new Date().toString());
		logger.info("SchedularService :: no.of records fetched :: {}  ::findAll ::  {} :: ", list.size(), list);
	}

	//@Scheduled(cron = "0 */4 * * * * ")  //4 min
	public void deleteRecordsAfterEvery10min() {
		List<SchedularTask> list = longrunjob.findAll();
		if (Optional.ofNullable(list).isPresent()) {
				longrunjob.deleteAll();
		}
		logger.info("SchedularService :: BEFORE :: no.of records found :: {}  ::", list.size());
		logger.info("SchedularService :: Delete  service call in {} :: ", new Date().toString());
		logger.info("SchedularService :: AFTER :: no.of records found :: {}  ::", list.size());
	}

	
	// schedular which runs  for seconds 
	
	//@Scheduled(cron = "0/20 * * * * * ") //20 Sec
	public void add2DBIn20Sec() {
		SchedularTask st = new SchedularTask();
		st.setName("user" + new Random().nextInt(200,500000));
		SchedularTask newSt = longrunjob.save(st);
		logger.info("SchedularService :: add2DB :: add  service call in {} :: {}", new Date().toString(), newSt);
	}

	// schdualr job to fetch records from DB after every 15 seconds

	/*
	 * 0/15 - Every 15 sec * - Every min * - Every Hour * - Every Day * - Every
	 * Month * - Every Year
	 * 
	 */

	//@Scheduled(cron = "0/30 * * * * * ") // 3  min 
	public void fetchDBIn30Sec() {
		List<SchedularTask> list = longrunjob.findAll();
		logger.info("SchedularService :: Fetchall :: add  service call in {} ", new Date().toString());
		logger.info("SchedularService :: no.of records fetched :: {}  ::findAll ::  {} :: ", list.size(), list);
	}

	//@Scheduled(cron = "0/35 * * * * * ")  //4 min
	public void deleteRecordsAfterEvery35Sec() {
		List<SchedularTask> list = longrunjob.findAll();
		if (Optional.ofNullable(list).isPresent()) {
				longrunjob.deleteAll();
		}
		logger.info("SchedularService :: BEFORE :: no.of records found :: {}  ::", list.size());
		logger.info("SchedularService :: Delete  service call in {} :: ", new Date().toString());
		logger.info("SchedularService :: AFTER :: no.of records found :: {}  ::", list.size());
	}
	
	/* FixedDelay - FixedRate */
	//@Scheduled(fixedDelay = 1000)
	public void fixedDelayMethod() throws InterruptedException {	
		LocalDateTime current = LocalDateTime.now();
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
		String formatedDateTime = current.format(format);
		logger.info("fixedDelayMethod :: :: Sheduler time  {}", formatedDateTime);			
	}
	//@Scheduled(fixedRate  = 1000)
	public void fixedRateMethod() throws InterruptedException {
		LocalDateTime current = LocalDateTime.now();
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
		String formatedDateTime = current.format(format);
		logger.info("fixedRateMethod :: Sheduler time  {}", formatedDateTime);	
		Thread.sleep(1000);
	}
	
	/*
	 *  PT - Period Time
	 *  02S - seconds
	 *  02M - minutes
	 *  02H - Hour
	 */	
	//@Scheduled(fixedRateString = "PT02M",initialDelay = 1000) 
	public void ffixedRateStringMethod() throws InterruptedException {
		LocalDateTime current = LocalDateTime.now();
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
		String formatedDateTime = current.format(format);
		logger.info("fixedRateString :: Sheduler time  {}", formatedDateTime);	
	}
	

	/*
	 * 0 - sec
	 * 0 - Every min 
	 * 20 - Every Hour  :: 8 PM 
	 * * - Every Day 
	 * * - Every Day of the Month
	 * TUE - Every Day of the Week   : Every Tuesday
	 * 
	 */
	
	//@Scheduled(cron = "0 0 20 * * SUN")   
	public void deleteRecordsOnEveryTuesDay08PM() {
		List<SchedularTask> list = longrunjob.findAll();
		if (Optional.ofNullable(list).isPresent()) {
				longrunjob.deleteAll();
		}
		logger.info("SchedularService :: BEFORE :: no.of records found :: {}  ::", list.size());
		logger.info("SchedularService :: Delete  service call in {} :: ", new Date().toString());
		logger.info("SchedularService :: AFTER :: no.of records found :: {}  ::", list.size());
	}
}
