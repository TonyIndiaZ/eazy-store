package com.doctorservices.utilHelper;

import org.springframework.beans.factory.annotation.Autowired;

import com.doctorservices.repository.CounterAppChildRepo;

public class UtilityHelper {
	


}
