package com.doctorservices.controller;


import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.doctorservices.entity.Doctor;
import com.doctorservices.repository.DoctorRepository;


@ExtendWith(MockitoExtension.class)

class DoctorControllerTest {
	  @Mock
	private DoctorRepository drepo;
	  @InjectMocks
	Doctor doctor;
	  
	  


}
