package com.doctorservices.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;


import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import com.doctorservices.entity.Doctor;

@ExtendWith(MockitoExtension.class)

@DataJpaTest
@AutoConfigureTestDatabase
class DoctorRepositoryTest {
	
	@Mock
	private DoctorRepository drepo;
	
	@Mock
	private TestEntityManager testEntityManager;
	
//	@InjectMocks
//	Doctor doctor; 
	  
	  
	  @BeforeEach
	  void setUp() {
			//GIVEN
		  
			Doctor doctor = new Doctor();
			doctor.setId(1L);
			doctor.setName("d1");
			doctor.setAge(21);
			doctor.setMobile("8767878987");
			doctor.setSpecialisation("cardiologist");
			
			testEntityManager.persist(doctor);
			

	  }
	  
	
	@Test
	void testFindByDoctor_NotEmpty() {
		
//		List<Doctor> actual =  drepo.findByName("d1");
//		System.out.println(actual);
//		
//		assertEquals("d1", actual.get(0).getName());
		
        
        
	}

}
