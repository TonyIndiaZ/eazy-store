package com.doctorservices.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.CALLS_REAL_METHODS;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import com.doctorservices.entity.Doctor;
import com.doctorservices.repository.DoctorRepository;

//@ExtendWith(MockitoExtension.class)
class DoctorServiceImplTest {

	@InjectMocks
	private DoctorServiceImpl dserviceimpl;

	@Mock
	private DoctorRepository drepo;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}
	

	// Mock Data
	public Doctor doctorDetails() {
		Doctor doctor = new Doctor();
		doctor.setId(1L);
		doctor.setAge(34);
		doctor.setName("Ramesh");
		return doctor;
	}

	@Test
	void should_successful_when_a_saveDoctor() {

		// Given

		Doctor doctor = doctorDetails();

		// Mock the calls
		when(drepo.save(doctor)).thenReturn(doctor);

		// when
		Doctor response = dserviceimpl.saveDoctor(doctor);

		// then
		assertEquals(doctor.getAge(), response.getAge());
		verify(drepo,times(1)).save(doctor);

	}

   
	@Test
	void should_return_AllDoctors() {
		//GIVEN
	List<Doctor> alldocs = new ArrayList<>();
	alldocs.add( new Doctor(1L,"D1",23,"9090909098","Cardiologist",3));
	alldocs.add( new Doctor(1L,"D1",23,"9090909098","Cardiologist",3));
	
	//Mock the call
	when(drepo.findAll()).thenReturn(alldocs);
	
	//WHEN
	List<Doctor> response = dserviceimpl.getAllDoctors();
	
	//THEN
	  assertEquals(alldocs.size(), response.size());
			
	}
	
	
	@Test
	void should_return_Doctor_by_Name() {
		//GIVEN		
		String name = "Tony";
		
		//WHEN
		
		
		
	    //THEN
		
	}

	

}
