package com.patientservice;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;


@EnableDiscoveryClient
@SpringBootApplication
public class PatientservicesApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(PatientservicesApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		System.out.println("Patient service running....");
		
	}

	
	@Bean
	public RestTemplate getRestTemp()
	{
		return new RestTemplate();
	}
	
	
}
