package com.patientservice.controller;


import java.net.URI;
import java.net.URISyntaxException;
import org.slf4j.Logger; 
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.patientservice.dto.AppointmentDTO;
import com.patientservice.dto.Doctor;
import com.patientservice.entity.Appointment;
import com.patientservice.exception.ResourceNotFoundException;
import com.patientservice.repository.AppointmentRepository;

import jakarta.validation.Valid;


@RestController
@RequestMapping("/api/v1/apmt")
public class Appointmentcontroller {

	@Autowired
	private AppointmentRepository arepo;

	@Autowired
	private RestTemplate restTemplate;

	private String url = "http://127.0.0.1:8082/api/v1/doctor";
	
	Logger log = LoggerFactory.getLogger(Appointmentcontroller.class);

//	@Autowired
//	private PatientServiceImpl patientServiceImpl;
	
	
	//save appointment
	@PostMapping("/bookAppointment")
	public ResponseEntity<?> bookyourappointment(@RequestBody Appointment appointment)   {
	   
		           //get doctor Id :
		          
		
						//set DoctorId
			     	    appointment.setDoctor_id(appointment.getDoctor_id());				
						//getpatientById - set to appointment table
           
						

						appointment.setPatient_id(appointment.getPatient_id());
						
						
						Appointment bookAppointment=arepo.save(appointment);
						//"Appointment Booked Successfully....";
						return new ResponseEntity<>(bookAppointment,HttpStatus.OK);
				
		            
				//return new ResponseEntity<>("Patient Id Not Found",HttpStatus.NOT_FOUND);
	}
	
	
	//get appointment details
	@GetMapping("/{id}")
	public ResponseEntity<AppointmentDTO> getAppointmentBookingDetails(@PathVariable Long id) throws URISyntaxException {
		//patient - full details 
		
		log.trace(":::::TRACE : Appointment DTO ::::::");
		log.info("::::: INFO :Appointment DTO ::::::");
		Appointment ap = arepo.findById(id).get();
		
		
		
		
		Long doctor_id = ap.getDoctor_id();
		
		//fetch ->data from doctor service
	    //Type 1:Doctor response = restTemplate.getForObject(url + "/" + doctor_id, Doctor.class);		
		//Type 2: using Exchange
		HttpHeaders headers = new HttpHeaders();
		RequestEntity<String> requestEntity = new RequestEntity<>(headers, HttpMethod.GET,new URI(url+"/"+doctor_id));		
		ResponseEntity<Doctor> responseEntity =restTemplate.exchange(requestEntity, new ParameterizedTypeReference<Doctor>() {
		});	
		Doctor response = responseEntity.getBody();
		
		AppointmentDTO dto = new AppointmentDTO();
		//set all values into DTO for Display purpose
		dto.setId(ap.getId());
		dto.setAppointmentDateTime(ap.getAppointmentDateTime());
		
		//doctor details
		dto.setDoctorId(doctor_id);
		dto.setName(response.getName());
		dto.setAge(response.getAge());
		dto.setMobile(response.getMobile());
		dto.setSpecialisation(response.getSpecialisation());
		
		//patient details
		dto.setPatientId(ap.getPatient_id().getPatientId());
		dto.setPatientName(ap.getPatient_id().getPatientName());
		dto.setPatientAge(ap.getPatient_id().getPatientAge());
		dto.setPatientMobile(ap.getPatient_id().getPatientMobile());		
		return new ResponseEntity<AppointmentDTO>(dto, HttpStatus.OK);
	}
	
	
	
	
	
	//post - doctor details from patient service
	
	@PostMapping("/saveDoctor")
	public ResponseEntity<Doctor> saveDoctorFromPatientService(@RequestBody @Valid Doctor doctor) {
		
		//headers
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);		
		HttpEntity<Doctor> requestEnity = new HttpEntity<>(doctor,headers);
		ResponseEntity<Doctor> responseEntity = restTemplate.exchange(url+"/save", HttpMethod.POST,requestEnity,Doctor.class);
		
		Doctor newDoctor = responseEntity.getBody();	
		return new ResponseEntity<Doctor>(newDoctor,HttpStatus.CREATED);
	}
	
	
}
	

