package com.patientservice.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.patientservice.dto.Doctor;
import com.patientservice.entity.Patient;

import com.patientservice.exception.ResourceNotFoundException;
import com.patientservice.service.PatientServiceImpl;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v1/patients")
//@CrossOrigin("*")
public class PatientController {

	@Autowired
	private PatientServiceImpl patientServiceImpl;

	@Autowired
	RestTemplate restTemplate;

	private String url = "http://127.0.0.1:8082/api/v1/doctor";
//	private String url = "http://DOCTORSERVICES/api/v1/doctor";

	// save
	@PostMapping("/save")
	public ResponseEntity<Patient> savePatient(@RequestBody @Valid Patient patient) {
		Patient saveNewPatient = patientServiceImpl.savePatient(patient);
		return new ResponseEntity<>(saveNewPatient, HttpStatus.CREATED);
	}

	// read - by Id ->native Query
	@GetMapping("/byId/{patient_id}")
	public ResponseEntity<Patient> getPatientById(@PathVariable("patient_id") Long id) {
		Patient patient = patientServiceImpl.getByPatientId(id);
		System.out.println("patient :" + patient);
		return ResponseEntity.ok(patient);

	}

	// read - by Name ->native Query
	@GetMapping("/byName/{patient_name}")
	public ResponseEntity<List<Patient>> getPatientByName(@PathVariable("patient_name") String name) {
		List<Patient> patient = patientServiceImpl.getByPatientName(name);
		return new ResponseEntity<>(patient, HttpStatus.OK);

	}

	// read - by allpatients
	@GetMapping("/allPatients")
	public ResponseEntity<List<Patient>> getAllpatients() {
		List<Patient> patient = patientServiceImpl.getAllPatients();
		return new ResponseEntity<>(patient, HttpStatus.OK);

	}

	// Delete -byId
	@DeleteMapping("/{patient_id}")
	public ResponseEntity<String> deletePatientById(@PathVariable("patient_id") Long id) {
		boolean flag = patientServiceImpl.deletePatientById(id);
		if (flag) {
			return new ResponseEntity<>("Patient deleted successfully..", HttpStatus.OK);

		}
		return new ResponseEntity<>("Patient Not Found With Given Id", HttpStatus.NOT_FOUND);

	}

	// update
	@PutMapping("/updatePatient/{patient_id}")
	public ResponseEntity<String> updatePatientById(@PathVariable("patient_id") Long patientId,
			@RequestBody @Valid Patient patient) {
		patientServiceImpl.updatePatientById(patientId, patient);
		return new ResponseEntity<>("Patient Updated successfully", HttpStatus.OK);

	}

//	-----------------------------     Doctor <=> Patient   ----------------------------------
	
	// Book appointment with Doctor service
	@GetMapping("/doctorservice/appointment")
	public String bookYourAppointment() {
		ResponseEntity<String> response = restTemplate.exchange(url + "/test", HttpMethod.GET, null,
				new ParameterizedTypeReference<String>() {
				});
		return response.getBody();

	}

	// From DoctorService
	@GetMapping("/doctorservice/{id}")
	public ResponseEntity<?> getDoctorsById(@PathVariable Long id) throws ResourceNotFoundException {

		try {
			HttpHeaders headers = new HttpHeaders();
			RequestEntity<String> requestEntity = new RequestEntity<>(headers, HttpMethod.GET, new URI(url + "/" + id));
			ResponseEntity<Doctor> responseEntity = restTemplate.exchange(requestEntity,
					new ParameterizedTypeReference<Doctor>() {
					});			
			Doctor doctorsList = responseEntity.getBody();
			return new ResponseEntity<>(doctorsList,HttpStatus.OK);
		} catch (RestClientException | URISyntaxException e) {	
			return new ResponseEntity<>("Data Not found with given Id: "+id,HttpStatus.NOT_FOUND);
		}
	}

	
	
	// From DoctorService - allDoctors
	@GetMapping("/doctorservice/allDoctors")
	public List<Doctor> getAllDoctors() {

		try {
			HttpHeaders headers = new HttpHeaders();
			RequestEntity<String> requestEntity = new RequestEntity<>(headers, HttpMethod.GET,
					new URI(url + "/alldoctors"));
			ResponseEntity<List<Doctor>> responseEntity = restTemplate.exchange(requestEntity,
					new ParameterizedTypeReference<List<Doctor>>() {
					});
			List<Doctor> doctorsList = responseEntity.getBody();
			System.out.println(doctorsList);
			return doctorsList;
		} catch (RestClientException | URISyntaxException e) {
			e.printStackTrace();
		}
		return null;

	}

}