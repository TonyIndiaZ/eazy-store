package com.patientservice.dto;

import java.time.LocalDateTime;

public class AppointmentDTO {

	private Long id;
	private LocalDateTime appointmentDateTime;
	//Patient- Details
	private Long patientId;
	private String patientName;
	private Integer patientAge;
	private String patientMobile;
	//Doctor -details
	private Long doctorId;
	private String name;
	private Integer age;
	private String specialisation;
	private String mobile;
	
	
	
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public LocalDateTime getAppointmentDateTime() {
		return appointmentDateTime;
	}
	public void setAppointmentDateTime(LocalDateTime appointmentDateTime) {
		this.appointmentDateTime = appointmentDateTime;
	}
	public Long getPatientId() {
		return patientId;
	}
	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public Integer getPatientAge() {
		return patientAge;
	}
	public void setPatientAge(Integer patientAge) {
		this.patientAge = patientAge;
	}
	public String getPatientMobile() {
		return patientMobile;
	}
	public void setPatientMobile(String patientMobile) {
		this.patientMobile = patientMobile;
	}
	public Long getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(Long doctorId) {
		this.doctorId = doctorId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public String getSpecialisation() {
		return specialisation;
	}
	public void setSpecialisation(String specialisation) {
		this.specialisation = specialisation;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public AppointmentDTO(Long id, LocalDateTime appointmentDateTime, Long patientId, String patientName, Integer patientAge,
			String patientMobile, Long doctorId, String name, Integer age, String specialisation, String mobile) {
		super();
		this.id = id;
		this.appointmentDateTime = appointmentDateTime;
		this.patientId = patientId;
		this.patientName = patientName;
		this.patientAge = patientAge;
		this.patientMobile = patientMobile;
		this.doctorId = doctorId;
		this.name = name;
		this.age = age;
		this.specialisation = specialisation;
		this.mobile = mobile;
	}
	public AppointmentDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "AppointmentDTO [id=" + id + ", appointmentDateTime=" + appointmentDateTime + ", patientId=" + patientId
				+ ", patientName=" + patientName + ", patientAge=" + patientAge + ", patientMobile=" + patientMobile
				+ ", doctorId=" + doctorId + ", name=" + name + ", age=" + age + ", specialisation=" + specialisation
				+ ", mobile=" + mobile + "]";
	}
	
	
	
	
}
