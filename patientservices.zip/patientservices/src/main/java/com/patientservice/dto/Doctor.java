package com.patientservice.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class Doctor {

	private Long id;
	
	@NotBlank(message = "Name is required")
	private String name;
	@Min(value=18,message = "Doctor age must be greater than 18 years")
	private Integer age;
	@Size(min=10,max=10,message = "Mobile Number must contains 10 digits")
	private String mobile;
	@NotBlank(message = "Name is required")
	private String specialisation;
	
	@Min(value=0,message = "Experience cann't be blank")
	private Integer experience;
	
	
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getSpecialisation() {
		return specialisation;
	}
	public void setSpecialisation(String specialisation) {
		this.specialisation = specialisation;
	}
	public Integer getExperience() {
		return experience;
	}
	public void setExperience(Integer experience) {
		this.experience = experience;
	}
	public Doctor(Long id, String name, Integer age, String mobile, String specialisation, Integer experience) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.mobile = mobile;
		this.specialisation = specialisation;
		this.experience = experience;
	}
	public Doctor() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	@Override
	public String toString() {
		return "Doctor [id=" + id + ", name=" + name + ", age=" + age + ", mobile=" + mobile + ", specialisation="
				+ specialisation + ", experience=" + experience + "]";
	}
	
	
}
