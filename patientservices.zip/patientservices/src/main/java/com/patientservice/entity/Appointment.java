package com.patientservice.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.NamedNativeQuery;

import jakarta.persistence.ColumnResult;
import jakarta.persistence.ConstructorResult;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SqlResultSetMapping;
import jakarta.persistence.Table;

@Entity
@Table(name = "appointment")
@SqlResultSetMapping(name = "AppointmentMapping", classes = @ConstructorResult(targetClass = Appointment.class, columns = {
		@ColumnResult(name = "id", type = Long.class),
		@ColumnResult(name = "appointmentDateTime", type = LocalDateTime.class) }))
@NamedNativeQuery(name = "Appointment.findByPatientId", query = "SELECT * FROM APPOINTMENT WHERE PatientId = :patientid", resultSetMapping = "AppointmentMapping")
				
public class Appointment {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private LocalDateTime appointmentDateTime;
	
	private Long doctor_id;	
	
	// many 
	@ManyToOne
	@JoinColumn(name="patient_id")
	private Patient patientId;

	
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public LocalDateTime getAppointmentDateTime() {
		return appointmentDateTime;
	}

	public void setAppointmentDateTime(LocalDateTime appointmentDateTime) {
		this.appointmentDateTime = appointmentDateTime;
	}

	public Long getDoctor_id() {
		return doctor_id;
	}

	public void setDoctor_id(Long doctor_id) {
		this.doctor_id = doctor_id;
	}

	public Patient getPatient_id() {
		return patientId;
	}

	public void setPatient_id(Patient patient_id) {
		this.patientId = patient_id;
	}

	public Appointment(Long id, LocalDateTime appointmentDateTime, Long doctor_id, Patient patient_id) {
		super();
		this.id = id;
		this.appointmentDateTime = appointmentDateTime;
		this.doctor_id = doctor_id;
		this.patientId = patient_id;
	}

	public Appointment() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Appointment [id=" + id + ", appointmentDateTime=" + appointmentDateTime + ", doctor_id=" + doctor_id
				+ ", patient_id=" + patientId + "]";
	}
	
	
	
}
