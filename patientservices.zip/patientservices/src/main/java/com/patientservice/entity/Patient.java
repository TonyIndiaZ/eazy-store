package com.patientservice.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;



@Table(name = "patient")
@Entity
public class Patient  {
	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long patientId;
	
	@Column(nullable = false)
	@NotBlank(message = "Patient Name cannot be blank")
	private String patientName;
	
	@Column(nullable = false)
	@Min(value=0, message = "Age must greater than 18 years")
	private Integer patientAge;
	
	@Column(nullable = false)
	@Size(min=10,max=10,message = "mobile must conatins 10 digits")
	private String patientMobile;
	
	
	
	
	
	public Long getPatientId() {
		return patientId;
	}
	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getPatientMobile() {
		return patientMobile;
	}
	public void setPatientMobile(String patientMobile) {
		this.patientMobile = patientMobile;
	}
	
	public Integer getPatientAge() {
		return patientAge;
	}
	public void setPatientAge(Integer patientAge) {
		this.patientAge = patientAge;
	}
	
	
	public Patient() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	
	public Patient(Long patientId,  String patientName,Integer patientAge,String patientMobile) {
		super();
		this.patientId = patientId;
		this.patientName = patientName;
		this.patientAge = patientAge;
		this.patientMobile = patientMobile;
	}
	@Override
	public String toString() {
		return "Patient [patientId=" + patientId + ", patientName=" + patientName + ", patientAge=" + patientAge
				+ ", patientMobile=" + patientMobile + "]";
	}

	
	

	
	

}
