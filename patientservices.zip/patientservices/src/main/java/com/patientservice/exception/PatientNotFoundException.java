package com.patientservice.exception;

@SuppressWarnings("serial")
public class PatientNotFoundException extends RuntimeException{
	public PatientNotFoundException(String message) {
		super(message);
	}
}
