package com.patientservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.patientservice.entity.Appointment;


@Repository
public interface AppointmentRepository extends JpaRepository<Appointment, Long>{
	
}
