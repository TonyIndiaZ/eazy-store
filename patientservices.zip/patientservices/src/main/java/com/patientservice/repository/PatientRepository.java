package com.patientservice.repository;



import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.patientservice.entity.Patient;

@Repository
public interface PatientRepository extends JpaRepository<Patient, Long>{

	//Search - by Id
	@Query(value="SELECT * FROM patient WHERE patient_id=:patient_id", nativeQuery = true)
	public Optional<Patient> findByPatientId(Long patient_id);
	
	
	//Search - by Name
	@Query(value="SELECT * FROM patient WHERE LOWER(patient_name)LIKE LOWER(CONCAT('%',:name,'%'))", nativeQuery = true)
	public Optional<List<Patient>> findByPatientNameIgnoreCase(String name);
	
	public List<Patient> findByPatientName(String name);
	
}
