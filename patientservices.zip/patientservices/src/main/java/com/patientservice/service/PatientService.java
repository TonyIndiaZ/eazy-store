package com.patientservice.service;


import java.util.List;
import com.patientservice.entity.Patient;
import com.patientservice.exception.PatientNotFoundException;



public interface PatientService {
	
	    // save
		public Patient savePatient(Patient patient);

		// read -by Id 
		public  Patient getByPatientId(long id) throws PatientNotFoundException;
		
		// read -by Name
		public List<Patient> getByPatientName(String name) throws PatientNotFoundException;
		
		// read - getAllDoctors
		public List<Patient> getAllPatients()throws PatientNotFoundException;

		// delete
		public Boolean deletePatientById(long id);
		
		
		//update 
		public Patient updatePatientById(long patientId,Patient patient );

}

