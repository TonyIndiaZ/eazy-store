package com.patientservice.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.patientservice.entity.Patient;
import com.patientservice.exception.PatientNotFoundException;
import com.patientservice.repository.PatientRepository;

@Service
public class PatientServiceImpl implements PatientService {

	@Autowired
	private PatientRepository patientrepository;

	// save
	@Override
	public Patient savePatient(Patient patient) {
		return patientrepository.save(patient);
	}

	// get by patientId
	@Override
	public Patient getByPatientId(long id) {
		return patientrepository.findByPatientId(id)
				.orElseThrow(() -> new PatientNotFoundException("Patient Not Found with given ID"));

	}

	// byPatientName
	@Override
	public List<Patient> getByPatientName(String name) {
		return patientrepository.findByPatientNameIgnoreCase(name)
				.orElseThrow(() -> new PatientNotFoundException("Patient Not Found With Given Name"));
	}

	//all patients
	@SuppressWarnings("unchecked")
	@Override
	public List<Patient> getAllPatients() {

		List<Patient> allPatients = patientrepository.findAll();
		if (allPatients != null) {
			return allPatients;
		}
		return (List<Patient>) new PatientNotFoundException("Patient is Empty.");
	}

	//delete -by Id
	@Override
	public Boolean deletePatientById(long id) {

		Optional<Patient> existingPatient = patientrepository.findById(id);
		if (existingPatient.isPresent()) {
			return true;
		}
		return false;
	}

	//update - by Id
	@Override
	public Patient updatePatientById(long patientId, Patient patient) {

		try {
			Patient editPatient = patientrepository.findById(patientId).get();
			editPatient.setPatientAge(patient.getPatientAge());
			editPatient.setPatientName(patient.getPatientName());
			editPatient.setPatientMobile(patient.getPatientMobile());
			return patientrepository.save(editPatient);
		} catch (Exception ex) {
			throw new PatientNotFoundException("Failed to update Patient,Incorrect PatientID");
		}

	}
}

