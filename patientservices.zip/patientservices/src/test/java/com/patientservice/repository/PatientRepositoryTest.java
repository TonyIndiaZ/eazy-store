package com.patientservice.repository;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.patientservice.entity.Patient;

public class PatientRepositoryTest {
	
	@Autowired
	private PatientRepository prepo;
	
	Patient patient;
	
	
	@BeforeEach
	void setuo() {
		patient = new Patient(10L, "tony", 23, "XXXXXXXXXX");		
		prepo.save(patient);
		
	}
	
	@AfterEach
	void tearDown() {
		
		patient =null;
		prepo.deleteAll();
	}
	
	@Test
	void testFindByPatientName_NotEmpty() {
		
		List<Patient> p = prepo.findByPatientName("Tony");   
		assertThat(p.get(0)).isEqualTo(patient.getPatientName());
	}

}
